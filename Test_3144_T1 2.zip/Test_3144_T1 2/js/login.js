function login(form)
{

  var form1 = document.getElementById("uname");
  var paswrd = document.getElementById("psw");
  if (form1.value == "Naksh" && paswrd.value == "naksh")
  {
    alert("logged in");
    window.location.href = "info.html";
  }
    else
    {
      alert("not ok");
    }
  }

  function validatePrice(){
    var price = document.getElementById("amountTransfer").value;

    var fromAccount = document.getElementsByClassName("fromAccount");
    var toAccount = document.getElementsByClassName("toAccount");

    if(1 > 0 ){
      if (isNaN(price)){
        alert("Enter Valid Amount");
      }
      else{
          //alert(price);
          if(price > 1000){
              alert("Insufficient Balance");
          }
          else if(price < 0){
              alert("Enter valid amount");
          }
          else{
              var balance = 1000 - price;
              //alert(balance);
              var updatedBalance =  document.getElementById("bal");
              updatedBalance.value = balance;
          }
      }
    }
    else{
      alert("Transfer should be made to a different account");
    }

  }
  function tran()
{
  validatePrice()
  cbal.value = bal.value


}
