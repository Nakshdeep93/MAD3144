

function login(form)
{

  var uname = document.getElementById("uname");
  var psw = document.getElementById("psw");
  if (form.uname.value == "Naksh" && form.psw.value == "naksh")
  {
  document.location.href = "info.html";
  }
  else if(form.uname.value == "test" && form.psw.value == "test")
     {
     document.location.href = "info.html";
     }
    else
    {
      alert("Enter valid username or password");
    }
  }




  // function validatePrice(){
  //   var price = document.getElementById("amountTransfer").value;
  //
  //   var fromAccount = document.getElementsByClassName("fromAccount");
  //   var toAccount = document.getElementsByClassName("toAccount");
  //
  //   if(1 > 0 ){
  //     if (isNaN(price)){
  //       alert("Enter Valid Amount");
  //     }
  //     else{
  //         //alert(price);
  //         if(price > 1000){
  //             alert("Insufficient Balance");
  //         }
  //         else if(price < 0){
  //             alert("Enter valid amount");
  //         }
  //         else{
  //             var balance = 1000 - price;
  //             //alert(balance);
  //             var updatedBalance =  document.getElementById("bal");
  //             updatedBalance.value = balance;
  //         }
  //     }
  //   }
  //   else{
  //     alert("Transfer should be made to a different account");
  //   }
  //
  // }
  //function tran()
//{
  //validatePrice()
//  cbal.value = bal.value
//}
function btntrans() {
  var sbalance=localStorage.getItem('sbalance');
   console.log(sbalance);
  var tbalance=0;
  tbalance=localStorage.getItem('tbalance');
  var sCreditAvilable=localStorage.getItem('sCreditAvilable');
  var tCreditAvilable=localStorage.getItem('tCreditAvilable');

  var bal = document.getElementById("bal");

  var tcredit = document.getElementById("tcredit");
   var acredit = document.getElementById("acredit");
  if (bal == null){
    localStorage.setItem('balance', '1000')
  }
  else {
    document.getElementById("cbal").value;
    var amt = document.getElementById("amt");


     if (amt.value < cbal.value) {

      bal.value = cbal.value - amt.value;
alert("Transfer Successful");
     }
     if (amt.value > cbal.value) {
     if(amt.value > (parseInt(bal.value)+parseInt(cbal.value))){
     alert("ERROR! Amount cannot be tranfered");
     location.reload();
     }

else{


      var temp=acredit.value - (amt.value - cbal.value);
       sbalance = 0;
      sCreditAvilable=  acredit.value - (amt.value - cbal.value);
      console.log(amt.value);
     tbalance=  (parseInt(tbalance) + parseInt(amt.value));
     console.log(tbalance);
       acredit.value=sCreditAvilable;
       bal.value =0;
       cbal.value =0;
       amt.value=0;
       alert("Transfer Successful");
     }
   }

  }
    //localStorage.setItem('balance', bal.value);
    localStorage.setItem('sbalance',bal.value);
    localStorage.setItem('tbalance', tbalance);
    localStorage.setItem('tcredit', sCreditAvilable);
    //localStorage.setItem('balance', bal.value);
}

function changePasswordtt()
{
  var oPass = document.getElementById("oldPass").value;
  var nPaswrd = document.getElementById("newPass").value;
  if(oPass == pas1)
  {
      pas1= nPaswrd;
      alert("Password changed");
      window.open("info.html");
  }
  else {
    alert("Wrong current Password");
  }
}



function logOut()
{
  window.open("login.html" );
}
