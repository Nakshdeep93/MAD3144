function login(form)
{

  var form1 = document.getElementById("uname");
  var paswrd = document.getElementById("psw");
  if (form1.value == "Naksh" && paswrd.value == "naksh")
  {
    alert("logged in");
  }
    else
    {
      alert("not ok");
    }
  }
